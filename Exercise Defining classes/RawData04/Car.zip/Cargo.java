package Exercises_DefiningClasses.RawData04;

public class Cargo {
    private int cargoWeight;
    private String cargoType;

    public Cargo(int cargoWeight,String cargoType){
        this.cargoType= cargoType;
        this.cargoWeight = cargoWeight;
    }
}
